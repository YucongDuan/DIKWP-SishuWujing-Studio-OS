# Student Study Plan

Overall route: guided_learning_required

## Units
- 大学 / U001: guided_self_study_allowed (S4 Stable Closure)
- 论语 / U002: teacher_guided_reading_required (S3 Supported Closure)
- 中庸 / U003: teacher_guided_reading_required (S3 Supported Closure)
- 孟子 / U004: guided_self_study_allowed (S4 Stable Closure)
- 诗经 / U005: guided_self_study_allowed (S4 Stable Closure)
- 周易 / U006: teacher_guided_reading_required (S4 Stable Closure)
- 礼记 / U007: teacher_guided_reading_required (S3 Supported Closure)
- 春秋 / U008: teacher_guided_reading_required (S4 Stable Closure)