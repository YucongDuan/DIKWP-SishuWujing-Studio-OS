# Teacher Lesson Pack

## Core Method
Use DIKWP ledger, source boundary, translation integrity, misreading guard, and modern ethical boundary.
- Review: 论语 / U002
- Review: 中庸 / U003
- Review: 周易 / U006
- Review: 礼记 / U007
- Review: 春秋 / U008