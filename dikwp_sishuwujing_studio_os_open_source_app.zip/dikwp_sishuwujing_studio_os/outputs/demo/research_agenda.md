# Research Agenda

- Four Books and Five Classics as DIKWP semantic governance material.
- Translation integrity of key terms.
- Anti-moral-capture reading of classical ethics.
- Classics and AI purpose-layer governance.
