# AI Use Policy

AI may assist with vocabulary, comparison, question generation, and DIKWP note structure. AI must not fabricate citations, present one final interpretation as absolute, or use classics to justify coercion, discrimination, violence, or legal replacement.
