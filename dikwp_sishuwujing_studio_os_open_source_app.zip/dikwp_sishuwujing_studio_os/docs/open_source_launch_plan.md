# Open Source Launch Plan

1. Publish repository as `DIKWP-SishuWujing-Studio-OS`.
2. Pin README, NOTICE, CITATION.cff.
3. Include standalone `index.html` demo.
4. Add sample case and screenshots.
5. Publish a short Chinese article: "用 DIKWP 学四书五经：不口号化、不道德绑架、不伪造确定性".
6. Invite teachers to contribute additional passages and rubrics.
7. Keep official DIKWP attribution and TrustPassport seed.
