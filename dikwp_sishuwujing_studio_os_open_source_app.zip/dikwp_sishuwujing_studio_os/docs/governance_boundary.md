# Governance Boundary

This project is an educational and research tool. It does not provide political doctrine, legal authority, religious authority, psychological diagnosis, or moral command.

Classics should not be used to coerce students, family members, employees, citizens, or vulnerable groups. Modern legal rights, personal dignity, safety, and plural interpretation must remain explicit boundaries.
