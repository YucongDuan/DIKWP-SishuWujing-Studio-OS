# Architecture

DIKWP SishuWujing Studio OS has four layers.

## 1. Intake Layer

Reads a JSON case containing learner profile, selected passages, concept tags, evidence references, common misreadings, teacher goals, and questions.

## 2. Semantic Layer

Each passage is mapped into C=(D,I,K,W,P,R). The system identifies source incompleteness, translation imprecision, interpretive inconsistency, harmful misreadings, and teacher review needs.

## 3. Pedagogy Layer

The system generates student plan, teacher pack, misconception map, concept cards, action tickets, and theory development matrix.

## 4. Boundary Layer

The guard prevents using classical authority for coercion, humiliation, discrimination, legal replacement, violence, and fabricated citations.
