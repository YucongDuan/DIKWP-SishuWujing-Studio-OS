# Assessment Rubrics

## Student Essay Rubric

- Text evidence: 25%
- Concept registration: 25%
- Misreading repair: 20%
- Modern application boundary: 20%
- Residual honesty: 10%

## Presentation Rubric

- Passage clarity.
- Historical context.
- Concept mapping.
- Counterinterpretation.
- Modern boundary.
- Action relevance.

## AI Use Rubric

- Did the student verify AI output?
- Did the student preserve source boundaries?
- Did the student avoid fabricated citations?
- Did the student name residuals?
