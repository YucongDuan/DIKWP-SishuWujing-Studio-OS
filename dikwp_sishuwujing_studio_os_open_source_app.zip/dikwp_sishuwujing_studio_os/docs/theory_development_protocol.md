# Theory Development Protocol

The Four Books and Five Classics can be used for modern theory development only after passing five gates.

1. Source Gate: text source and passage boundary are clear.
2. Translation Gate: term ambiguity is preserved.
3. Context Gate: historical context is not erased.
4. Misreading Gate: likely abuse is named.
5. Purpose Gate: modern use has a legitimate purpose and action boundary.

Modern development directions:

- Confucian learning and AI education.
- Ritual and organization governance.
- Spring and Autumn narrative and institutional accountability.
- Changes and uncertainty reasoning.
- Poetry and affective education.
- DIKWP semantic governance of classical terms.
