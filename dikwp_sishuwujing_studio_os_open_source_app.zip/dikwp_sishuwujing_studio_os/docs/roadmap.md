# Roadmap

## v0.2

- Add passage database.
- Add multiple commentary traditions.
- Add bilingual term cards.
- Add teacher assignment generator.

## v0.3

- Add school course mode.
- Add comparative philosophy adapter.
- Add AI ethics lesson pack.

## v1.0

- Full Four Books and Five Classics learning map.
- Teacher dashboard.
- Contribution registry.
- TrustPassport integration.
