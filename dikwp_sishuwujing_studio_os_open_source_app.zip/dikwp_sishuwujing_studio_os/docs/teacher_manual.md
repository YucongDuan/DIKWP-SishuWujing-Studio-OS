# Teacher Manual

## Class Method

1. Begin with a passage.
2. Ask students to identify the text source and uncertainty.
3. Register core concepts as D/I/K/W/P/R.
4. Compare two possible interpretations.
5. Identify a likely misuse.
6. Reframe with modern ethical and legal boundaries.
7. Write a residual: what remains unresolved?

## Teaching Modes

- Textual reading.
- Concept laboratory.
- Misreading repair.
- Modern application discussion.
- AI-assisted note-making.

## Teacher Responsibility

Teachers should not present any single interpretation as ultimate. The goal is to train evidence, context, boundaries, and reflective judgment.
