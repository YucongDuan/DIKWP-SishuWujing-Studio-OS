# Four Books and Five Classics Canon Map

## Four Books

- Great Learning / 大学：learning, self-cultivation, order of priorities, public purpose.
- Doctrine of the Mean / 中庸：dynamic appropriateness, sincerity, time-sensitive judgment.
- Analects / 论语：learning, ren, ritual practice, speech, governance, teacher-student relation.
- Mencius / 孟子：ren-yi, human sprouts, political legitimacy, moral psychology.

## Five Classics

- Book of Songs / 诗经：poetry, affect, social observation, indirect expression.
- Book of Documents / 尚书：political speech, mandate, governance record, legitimacy.
- Book of Rites / 礼记：ritual, institutions, social order, education and conduct.
- Book of Changes / 周易：change, images, uncertainty, timing and relation.
- Spring and Autumn Annals / 春秋：historical judgment, naming, narrative condensation.
