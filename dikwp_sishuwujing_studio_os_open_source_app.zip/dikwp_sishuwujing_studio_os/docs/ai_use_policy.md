# AI Use Policy

AI may be used for:

- Vocabulary explanation.
- Passage comparison.
- Study plan generation.
- Quiz generation.
- DIKWP note templates.
- Misreading detection.

AI must not be used to:

- Fabricate citations.
- Claim one final absolute interpretation.
- Justify coercion or discrimination.
- Replace teacher judgment.
- Replace law, mental health support, or professional advice.
- Generate humiliating or manipulative uses of classics.
