# DIKWP Model Mapping

A classical passage is not just a sentence. It is a semantic object.

- D / Data: the explicit text, source, work, chapter, received wording.
- I / Information: relation among characters, context, terms, historical setting.
- K / Knowledge: commentarial tradition, philology, philosophical interpretation, institutional knowledge.
- W / Wisdom: value ordering, ethical boundary, human dignity, modern legal context.
- P / Purpose: learning purpose, self-cultivation purpose, public reasoning purpose, research purpose.
- R / Reliability: source strength, translation uncertainty, interpretive controversy, residuals, kill conditions.

This system treats every major concept as an auditable DIKWP object rather than a slogan.
