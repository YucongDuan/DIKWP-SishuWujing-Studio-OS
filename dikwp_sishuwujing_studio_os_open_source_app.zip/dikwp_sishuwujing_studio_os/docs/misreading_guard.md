# Misreading Guard

## Block and Reframe

The system blocks uses that turn classics into coercive authority.

Examples:

- Use Confucian texts to demand absolute obedience.
- Use ritual to naturalize hierarchy or discrimination.
- Use filial piety to justify family coercion.
- Use classics to replace law or professional judgment.
- Use classical authority to humiliate students.

## Teacher Review Required

Context-sensitive topics should be guided by a teacher:

- Loyalty / 忠
- Filial piety / 孝
- Ritual / 礼
- Mandate / 天命
- Ruler-minister / 君臣
- Parent-child / 父子
- Husband-wife / 夫妇

## Safe Reframe

Return to text, context, translation, historical difference, modern dignity, and lawful boundaries.
