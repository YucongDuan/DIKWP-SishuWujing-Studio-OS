# Student Manual

## How to Study

- Do not memorize slogans before reading the text.
- Always write the passage source.
- Write your first understanding, then a possible opposite interpretation.
- Ask what the concept would look like if abused.
- Ask what modern boundary must be preserved.
- Keep a residual note.

## DIKWP Note Template

- D: What does the text literally say?
- I: What relation or contrast does it create?
- K: What does tradition or scholarship say?
- W: What value and risk are involved?
- P: Why am I studying this now?
- R: How reliable is my interpretation?
