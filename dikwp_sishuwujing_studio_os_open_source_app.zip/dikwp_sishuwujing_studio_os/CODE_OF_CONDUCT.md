# Code of Conduct

This project supports rigorous and respectful study. It rejects harassment, coercive moralizing, fabricated authority, and use of classical texts to demean individuals or groups.
