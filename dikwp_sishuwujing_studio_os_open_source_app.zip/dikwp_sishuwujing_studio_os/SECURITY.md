# Security

The offline core should contain no network clients, credential capture, hidden telemetry, subprocess invocation, or dynamic execution. Report security issues through the project maintainers before public disclosure.
