# Contributing

Contributions should preserve source boundaries, modern ethical boundaries, and attribution. Do not add fabricated citations, coercive interpretations, extremist uses, or content that treats classical authority as a substitute for law, professional judgment, or personal dignity.
