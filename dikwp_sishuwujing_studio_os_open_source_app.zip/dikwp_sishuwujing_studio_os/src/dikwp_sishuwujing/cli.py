from __future__ import annotations
import argparse, json, csv
from pathlib import Path
from .analyzer import load_case, analyze, guard_request
from .static_audit import audit

def write_outputs(report: dict, outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "sishuwujing_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with (outdir / "concept_cards.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["concept","D","I","K","W","P","R"])
        w.writeheader(); w.writerows(report["concept_ledger"])
    with (outdir / "decision_cards.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["unit_id","work","route","readiness_score","semantic_stability","risks","recommended_actions"])
        w.writeheader()
        for r in report["decision_cards"]:
            rr = dict(r); rr["risks"] = ";".join(rr.get("risks", [])); rr["recommended_actions"] = ";".join(rr.get("recommended_actions", [])); w.writerow(rr)
    with (outdir / "misconception_map.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["misconception","diagnosis","repair"])
        w.writeheader(); w.writerows(report["misconception_map"])
    with (outdir / "theory_development_matrix.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["concept","modern_problem","dikwp_development","research_question"])
        w.writeheader(); w.writerows(report["theory_development_matrix"])
    with (outdir / "action_tickets.csv").open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["ticket_id","owner","priority","action","evidence_refs","rollback_plan","kill_conditions"])
        w.writeheader()
        for r in report["action_tickets"]:
            rr = dict(r); rr["evidence_refs"] = ";".join(rr.get("evidence_refs", [])); rr["kill_conditions"] = ";".join(rr.get("kill_conditions", [])); w.writerow(rr)
    # Markdown deliverables
    from .analyzer import build_student_plan, build_teacher_pack, load_case, decision_for_unit
    # Reconstruct not needed; minimal based on report
    student_lines = ["# Student Study Plan", "", f"Overall route: {report['overall_route']}", "", "## Units"]
    for c in report["decision_cards"]:
        student_lines.append(f"- {c['work']} / {c['unit_id']}: {c['route']} ({c['semantic_stability']})")
    (outdir / "student_study_plan.md").write_text("\n".join(student_lines), encoding="utf-8")
    teacher_lines = ["# Teacher Lesson Pack", "", "## Core Method", "Use DIKWP ledger, source boundary, translation integrity, misreading guard, and modern ethical boundary."]
    for c in report["decision_cards"]:
        if c["route"] != "guided_self_study_allowed": teacher_lines.append(f"- Review: {c['work']} / {c['unit_id']}")
    (outdir / "teacher_lesson_pack.md").write_text("\n".join(teacher_lines), encoding="utf-8")
    (outdir / "ai_use_policy.md").write_text("# AI Use Policy\n\nAI may assist with vocabulary, comparison, question generation, and DIKWP note structure. AI must not fabricate citations, present one final interpretation as absolute, or use classics to justify coercion, discrimination, violence, or legal replacement.\n", encoding="utf-8")
    (outdir / "research_agenda.md").write_text("# Research Agenda\n\n- Four Books and Five Classics as DIKWP semantic governance material.\n- Translation integrity of key terms.\n- Anti-moral-capture reading of classical ethics.\n- Classics and AI purpose-layer governance.\n", encoding="utf-8")

def main() -> None:
    p = argparse.ArgumentParser(prog="sishuwujing")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze"); a.add_argument("case"); a.add_argument("--out", default="outputs/demo")
    g = sub.add_parser("guard"); g.add_argument("text", nargs="+")
    s = sub.add_parser("static-audit"); s.add_argument("root"); s.add_argument("--out")
    args = p.parse_args()
    if args.cmd == "analyze":
        case = load_case(args.case); report = analyze(case); write_outputs(report, Path(args.out)); print(json.dumps(report, ensure_ascii=False, indent=2))
    elif args.cmd == "guard":
        print(json.dumps(guard_request(" ".join(args.text)).__dict__, ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        r = audit(args.root); print(json.dumps(r, ensure_ascii=False, indent=2));
        if args.out: Path(args.out).write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__": main()
