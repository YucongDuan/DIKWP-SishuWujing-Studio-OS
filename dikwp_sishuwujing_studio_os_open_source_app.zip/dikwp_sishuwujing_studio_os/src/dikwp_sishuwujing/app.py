try:
    import streamlit as st
except Exception:
    st = None
from .analyzer import load_case, analyze

def main():
    if st is None:
        print("Streamlit is optional. Install with pip install -e .[app]")
        return
    st.title("DIKWP SishuWujing Studio OS")
    path = st.text_input("Case JSON", "examples/sample_classics_learning_case.json")
    if st.button("Analyze"):
        report = analyze(load_case(path))
        st.json(report)
if __name__ == "__main__": main()
