from __future__ import annotations
from pathlib import Path
import re, json
FORBIDDEN = [
    r"import\s+requests", r"import\s+socket", r"urllib", r"subprocess", r"os\.system", r"eval\(", r"exec\(",
    r"openai", r"httpx", r"selenium", r"playwright", r"credential", r"password", r"hidden telemetry"
]

def audit(root: str | Path) -> dict:
    root = Path(root)
    findings = []
    for path in root.rglob("*.py"):
        if path.name == "static_audit.py":
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pat in FORBIDDEN:
            if re.search(pat, text):
                findings.append({"file": str(path), "pattern": pat})
    return {"pass": not findings, "finding_count": len(findings), "findings": findings,
            "policy": "No network imports, subprocess, dynamic execution, hidden telemetry, credential capture, extremist or coercive uses in offline core."}

if __name__ == "__main__":
    import sys
    print(json.dumps(audit(sys.argv[1] if len(sys.argv)>1 else "src"), ensure_ascii=False, indent=2))
