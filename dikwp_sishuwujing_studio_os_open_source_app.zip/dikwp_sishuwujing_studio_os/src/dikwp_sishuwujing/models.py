from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class LearnerProfile:
    learner_id: str
    role: str = "student"
    classical_chinese_level: float = 0.3
    study_goal: str = "understand the Four Books and Five Classics"
    weekly_minutes: int = 180
    constraints: List[str] = field(default_factory=list)
    preferred_mode: str = "guided_reading"

@dataclass
class CanonUnit:
    unit_id: str
    canon_group: str
    work: str
    passage_title: str
    passage: str
    modern_hint: str
    concept_tags: List[str] = field(default_factory=list)
    difficulty: float = 0.5
    evidence_refs: List[str] = field(default_factory=list)
    common_misreadings: List[str] = field(default_factory=list)

@dataclass
class LearningCase:
    case_id: str
    learner: LearnerProfile
    units: List[CanonUnit]
    teacher_goals: List[str] = field(default_factory=list)
    institution_context: str = "general education"
    questions: List[str] = field(default_factory=list)

@dataclass
class ConceptLedgerEntry:
    concept: str
    D: str
    I: str
    K: str
    W: str
    P: str
    R: str

@dataclass
class DecisionCard:
    unit_id: str
    work: str
    route: str
    readiness_score: float
    semantic_stability: str
    risks: List[str]
    recommended_actions: List[str]

@dataclass
class ActionTicket:
    ticket_id: str
    owner: str
    priority: str
    action: str
    evidence_refs: List[str]
    rollback_plan: str
    kill_conditions: List[str]

@dataclass
class GuardResult:
    decision: str
    risk_categories: List[str]
    safe_redirect: str


def to_dict(obj: Any) -> Dict[str, Any]:
    return asdict(obj)
