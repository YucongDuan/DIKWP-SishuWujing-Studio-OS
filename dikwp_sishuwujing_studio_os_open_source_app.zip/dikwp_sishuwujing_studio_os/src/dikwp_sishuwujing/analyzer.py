from __future__ import annotations
import json, math, re
from pathlib import Path
from typing import Any, Dict, List, Tuple
from .models import LearnerProfile, CanonUnit, LearningCase, ConceptLedgerEntry, DecisionCard, ActionTicket, GuardResult

CORE_CONCEPTS = {
    "ren": ("仁", "以人际生命感通、恻隐、亲亲推扩为核心的德性语义对象。"),
    "yi": ("义", "在具体处境中辨别应当与不应当的行动边界。"),
    "li": ("礼", "把关系、秩序、仪式、分寸与制度化行为连接起来的规范结构。"),
    "zhi": ("智", "从经验、文本、时势和后果中形成判断的能力。"),
    "xin": ("信", "言行可验证、关系可持续和制度可依赖的可信结构。"),
    "zhongyong": ("中庸", "不是平庸折中，而是在张力中保持恰当、时中和可持续的判断。"),
    "gewu": ("格物", "对对象、关系、证据和本末次第的澄清。"),
    "tianming": ("天命", "古典语境中秩序、限制、正当性和自我修养边界的复合概念。"),
    "shi_jiao": ("诗教", "以诗歌训练情感、比兴、观察与社会表达的教育方式。"),
    "chunqiu": ("春秋义法", "通过叙事、称谓和书法显露价值判断与政治伦理边界。"),
    "yi_xiang": ("易象", "用卦象、变动和关系模型理解不确定处境的象征系统。"),
}

HARMFUL_MISREADING_PATTERNS = [
    (re.compile(r"愚忠|绝对服从|无条件服从|不能质疑"), "obedience_abuse"),
    (re.compile(r"女人.*服从|父权|男尊女卑|三从四德.*强制"), "patriarchy_abuse"),
    (re.compile(r"用.*论语.*控制|用.*经典.*压制|道德绑架"), "moral_capture"),
    (re.compile(r"等级.*天经地义|阶层.*固定|贵贱.*天命"), "hierarchy_naturalization"),
    (re.compile(r"体罚|羞辱|惩罚学生|打骂"), "education_harm"),
    (re.compile(r"复古.*替代法律|经典.*高于法律"), "legal_replacement"),
]

REVIEW_PATTERNS = [
    (re.compile(r"忠孝|君臣|父子|夫妇|礼制|天命"), "context_sensitive_classical_term"),
    (re.compile(r"考试|高考|考研|国学班|儿童"), "education_context"),
]

WORK_WEIGHTS = {
    "论语": 0.55, "孟子": 0.6, "大学": 0.45, "中庸": 0.65,
    "诗经": 0.55, "尚书": 0.75, "礼记": 0.7, "周易": 0.85, "春秋": 0.8,
}

def load_case(path: str | Path) -> LearningCase:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    learner = LearnerProfile(**data.get("learner", {}))
    units = [CanonUnit(**u) for u in data.get("units", [])]
    return LearningCase(
        case_id=data.get("case_id", "case-001"),
        learner=learner,
        units=units,
        teacher_goals=data.get("teacher_goals", []),
        institution_context=data.get("institution_context", "general education"),
        questions=data.get("questions", [])
    )

def clamp(x: float, lo=0.0, hi=1.0) -> float:
    return max(lo, min(hi, x))

def semantic_grade(score: float) -> str:
    if score >= 0.85: return "S4 Stable Closure"
    if score >= 0.68: return "S3 Supported Closure"
    if score >= 0.48: return "S2 Provisional Closure"
    if score >= 0.30: return "S1 Fragile Closure"
    return "S0 Blocked Closure"

def guard_request(text: str) -> GuardResult:
    risks = []
    for pat, name in HARMFUL_MISREADING_PATTERNS:
        if pat.search(text):
            risks.append(name)
    for pat, name in REVIEW_PATTERNS:
        if pat.search(text):
            risks.append(name)
    if any(r in risks for r in ["obedience_abuse", "patriarchy_abuse", "moral_capture", "education_harm", "legal_replacement"]):
        return GuardResult(
            decision="block_and_reframe",
            risk_categories=risks,
            safe_redirect="将经典解释为历史语境、概念学习和现代伦理讨论对象，不得用于控制、羞辱、压制、替代法律或剥夺个人边界。"
        )
    if risks:
        return GuardResult(
            decision="teacher_or_context_review_required",
            risk_categories=risks,
            safe_redirect="补充文本来源、历史语境、翻译差异、现代制度边界和反例，再进行讨论。"
        )
    return GuardResult(decision="allow_learning", risk_categories=[], safe_redirect="可作为文本细读、概念比较和学习讨论使用。")

def detect_unit_risks(unit: CanonUnit) -> List[str]:
    text = unit.passage + " " + " ".join(unit.common_misreadings)
    gr = guard_request(text)
    return gr.risk_categories

def compute_readiness(unit: CanonUnit, learner: LearnerProfile) -> float:
    base = learner.classical_chinese_level
    difficulty = unit.difficulty or WORK_WEIGHTS.get(unit.work, 0.6)
    time_factor = clamp(learner.weekly_minutes / 240.0)
    evidence_factor = 0.3 + 0.1 * min(len(unit.evidence_refs), 4)
    concept_factor = 0.45 + 0.07 * min(len(unit.concept_tags), 5)
    return round(clamp(0.42 * base + 0.20 * time_factor + 0.20 * evidence_factor + 0.18 * concept_factor - 0.22 * difficulty + 0.18), 3)

def decision_for_unit(unit: CanonUnit, learner: LearnerProfile) -> DecisionCard:
    readiness = compute_readiness(unit, learner)
    risks = detect_unit_risks(unit)
    source_score = 0.25 if unit.evidence_refs else 0.08
    passage_score = 0.18 if unit.passage else 0.04
    concept_score = 0.25 * clamp(len(unit.concept_tags) / 4)
    context_score = 0.18 if unit.modern_hint else 0.05
    risk_penalty = 0.12 if risks else 0
    stability_score = clamp(source_score + passage_score + concept_score + context_score + readiness * 0.25 - risk_penalty)
    stability = semantic_grade(stability_score)
    if any(r in risks for r in ["obedience_abuse", "patriarchy_abuse", "moral_capture", "education_harm", "legal_replacement"]):
        route = "block_and_reframe"
    elif risks or readiness < 0.45 or unit.difficulty > 0.72:
        route = "teacher_guided_reading_required"
    else:
        route = "guided_self_study_allowed"
    actions = []
    if route == "guided_self_study_allowed":
        actions = ["先读原文", "再看现代提示", "写出 D/I/K/W/P/R 六层笔记", "用一个现实例子验证概念边界"]
    elif route == "teacher_guided_reading_required":
        actions = ["补充时代语境", "核对关键字词", "比较至少两种解释", "先列误读风险再讨论现实应用"]
    else:
        actions = ["停止将经典用于压制性结论", "改为历史语境与现代伦理边界讨论", "加入现代法律、人权和教育保护边界"]
    return DecisionCard(unit.unit_id, unit.work, route, readiness, stability, risks, actions)

def concept_ledger(units: List[CanonUnit]) -> List[ConceptLedgerEntry]:
    seen = []
    for u in units:
        for tag in u.concept_tags:
            if tag not in seen: seen.append(tag)
    entries: List[ConceptLedgerEntry] = []
    for tag in seen:
        zh, desc = CORE_CONCEPTS.get(tag, (tag, "需要教师或研究者补充定义的概念。"))
        entries.append(ConceptLedgerEntry(
            concept=zh,
            D=f"文本中出现或相关的概念标签：{tag}。",
            I=f"该概念与其他德目、制度、情境和行动选择形成关系，不可孤立解释。{desc}",
            K="需要结合原文、注疏、历史语境、现代问题和反例来理解。",
            W="不得将其直接变成压迫、羞辱、绝对服从或道德绑架工具。",
            P="用于提升文本理解、价值辨析、修身反思和现代语义治理能力。",
            R="Supported as learning object; interpretation remains provisional when source, period, translation or context is missing."
        ))
    return entries

def build_student_plan(case: LearningCase, cards: List[DecisionCard]) -> str:
    lines = [f"# Student Study Plan for {case.case_id}", "", "## 学习原则", "- 先原文，后翻译，再现实应用。", "- 每个概念都写 D/I/K/W/P/R 六层笔记。", "- 不把经典当作压制他人的口号。", "- 遇到忠孝、礼制、天命、君臣、父子等高张力概念，必须补充历史语境和现代边界。", ""]
    lines.append("## 四周路径")
    weeks = [
        ("第一周：四书入门", "大学、论语、孟子、中庸；重点是学习、修身、仁义、时中。"),
        ("第二周：五经结构", "诗、书、礼、易、春秋；重点是情感、政事、礼制、变易、叙事判断。"),
        ("第三周：概念比较", "仁义礼智信、中庸、格物、天命、诗教、易象、春秋义法。"),
        ("第四周：现代应用", "AI 伦理、组织治理、家庭关系、教育、公共服务与现代法治边界。"),
    ]
    for title, body in weeks:
        lines.append(f"### {title}\n{body}")
    lines.append("\n## 本案例单元建议")
    for c in cards:
        lines.append(f"- {c.work} / {c.unit_id}: {c.route}，稳定性 {c.semantic_stability}，建议：{'；'.join(c.recommended_actions)}。")
    return "\n".join(lines)

def build_teacher_pack(case: LearningCase, cards: List[DecisionCard]) -> str:
    lines = [f"# Teacher Lesson Pack for {case.case_id}", "", "## 教学目标", "- 让学生理解四书五经不是口号库，而是复杂文本传统。", "- 训练原文证据、概念边界、翻译差异、现代应用和误读修复。", "- 用 DIKWP 结构组织学习：D/I/K/W/P/R。", ""]
    lines.append("## 课堂结构")
    lines += ["1. 导入：让学生说出一个自己听过的经典名句，并登记出处不确定性。", "2. 文本细读：每组只读一段，先不下结论。", "3. 概念注册：将关键词注册为 D/I/K/W/P/R。", "4. 误读实验：让学生列出该概念最容易被滥用的三种方式。", "5. 现代边界：加入现代法律、教育、人格尊严和公共治理语境。", "6. 反思：保留 Residual，不给唯一终极解释。", ""]
    lines.append("## 评分 Rubric")
    lines += ["- 文本证据 25%", "- 概念注册完整度 25%", "- 误读修复能力 20%", "- 现代应用边界 20%", "- Residual 诚实度 10%", ""]
    lines.append("## 需要教师重点复核的单元")
    for c in cards:
        if c.route != "guided_self_study_allowed":
            lines.append(f"- {c.work} / {c.unit_id}: {c.route}; risks={','.join(c.risks) or 'context/difficulty'}")
    return "\n".join(lines)

def build_misconception_map(units: List[CanonUnit]) -> List[Dict[str, Any]]:
    rows = []
    base = [
        ("把忠解释成绝对服从", "忠在不同文本中与诚、责、谏、职分有关，不等于取消判断。", "加入劝谏、责任、现代法治和个人边界。"),
        ("把礼解释成等级压迫", "礼既有历史制度性，也有分寸、秩序和互相承认的一面。", "区分古代制度和现代伦理，不得自然化压迫。"),
        ("把中庸解释成平庸折中", "中庸更接近时中、恰当、不过不及和动态平衡。", "用复杂冲突案例训练边界判断。"),
        ("把仁解释成无边界善良", "仁需要与义、礼、智配合，不等于无限牺牲自己。", "加入成本承担者和可持续性分析。"),
        ("把天命解释成宿命论", "天命在文本中常涉及正当性、责任和自我修养，而非消极服从。", "比较命、时、德、责和行动空间。"),
    ]
    for misconception, diagnosis, repair in base:
        rows.append({"misconception": misconception, "diagnosis": diagnosis, "repair": repair})
    for u in units:
        for m in u.common_misreadings:
            rows.append({"misconception": m, "diagnosis": "来自具体文本单元的潜在误读。", "repair": "回到原文、语境、注释和现代边界重新解释。"})
    return rows

def build_theory_matrix(concepts: List[ConceptLedgerEntry]) -> List[Dict[str, str]]:
    rows = []
    for e in concepts:
        rows.append({
            "concept": e.concept,
            "modern_problem": "AI治理 / 教育 / 组织治理 / 家庭关系 / 公共伦理",
            "dikwp_development": "将古典概念从德目词转化为可审计语义对象。",
            "research_question": f"{e.concept} 在现代社会中如何避免口号化、道德绑架和制度误用？"
        })
    return rows

def build_action_tickets(cards: List[DecisionCard]) -> List[ActionTicket]:
    tickets = []
    for i, c in enumerate(cards, start=1):
        if c.route == "guided_self_study_allowed":
            priority = "normal"; owner = "student"; action = f"完成 {c.work} / {c.unit_id} 的 DIKWP 笔记。"
        elif c.route == "teacher_guided_reading_required":
            priority = "high"; owner = "teacher"; action = f"为 {c.work} / {c.unit_id} 补充文本来源、译文差异和误读边界。"
        else:
            priority = "urgent"; owner = "teacher_or_guardian"; action = f"重构 {c.work} / {c.unit_id} 的讨论，移除压制性/伤害性用法。"
        tickets.append(ActionTicket(
            ticket_id=f"ticket-{i:03d}", owner=owner, priority=priority, action=action,
            evidence_refs=[c.unit_id], rollback_plan="回到原文证据和课堂讨论，不使用未经证实的口号式结论。",
            kill_conditions=["将经典用于压迫具体个人或群体", "删除现代法律与安全边界", "伪造原文出处"]
        ))
    return tickets

def analyze(case: LearningCase) -> Dict[str, Any]:
    cards = [decision_for_unit(u, case.learner) for u in case.units]
    ledgers = concept_ledger(case.units)
    misconceptions = build_misconception_map(case.units)
    matrix = build_theory_matrix(ledgers)
    tickets = build_action_tickets(cards)
    avg_readiness = round(sum(c.readiness_score for c in cards) / max(1, len(cards)), 3)
    blocked = sum(1 for c in cards if c.route == "block_and_reframe")
    guided = sum(1 for c in cards if c.route == "teacher_guided_reading_required")
    self_study = sum(1 for c in cards if c.route == "guided_self_study_allowed")
    if blocked:
        overall = "proceed_only_after_reframing"
    elif guided:
        overall = "guided_learning_required"
    else:
        overall = "self_study_with_reflection_allowed"
    return {
        "system": "DIKWP SishuWujing Studio OS",
        "version": "0.1.0",
        "case_id": case.case_id,
        "overall_route": overall,
        "unit_count": len(case.units),
        "mean_readiness": avg_readiness,
        "route_summary": {"guided_self_study_allowed": self_study, "teacher_guided_reading_required": guided, "block_and_reframe": blocked},
        "decision_cards": [c.__dict__ for c in cards],
        "concept_ledger": [e.__dict__ for e in ledgers],
        "misconception_map": misconceptions,
        "theory_development_matrix": matrix,
        "action_tickets": [t.__dict__ for t in tickets],
        "semantic_closure": {
            "three_no": ["source incompleteness", "translation imprecision", "interpretive inconsistency"],
            "primary_anchors": ["explicit classical passage", "canon work", "concept tag", "learning purpose"],
            "residuals": ["版本差异", "注疏差异", "德文/英文等二手译介不适用", "现代制度边界需要教师说明"],
            "stability_grade": "S3 Supported Closure" if guided or blocked else "S4 Stable Closure"
        }
    }
