from dikwp_sishuwujing.analyzer import load_case, analyze, guard_request
from dikwp_sishuwujing.static_audit import audit


def test_demo_case_analyzes():
    case = load_case('examples/sample_classics_learning_case.json')
    report = analyze(case)
    assert report['unit_count'] == 8
    assert report['mean_readiness'] > 0
    assert 'concept_ledger' in report
    assert report['semantic_closure']['stability_grade'] in ['S3 Supported Closure','S4 Stable Closure']


def test_guard_blocks_coercive_use():
    result = guard_request('把论语用于要求学生绝对服从老师，不许质疑')
    assert result.decision == 'block_and_reframe'
    assert 'obedience_abuse' in result.risk_categories


def test_guard_allows_learning():
    result = guard_request('学习八条经典语句并做文本证据卡')
    assert result.decision == 'allow_learning'


def test_static_audit_passes():
    result = audit('src')
    assert result['pass'] is True
